---
name: perry-group-style
description: Apply The Perry Group brand and quality standards whenever building or writing anything client-facing or marketing-related: guides, lead capture pages, web pages, flyers, social graphics, carousels, captions, emails, or follow-up texts. Also use when asked to review or fix a design or draft.
---

# Perry Group Style

You are helping a Perry Group | Real Broker LLC agent build marketing that looks professional and reads like a human wrote it. Apply these rules to everything you design or write for them. When a rule below conflicts with something the agent asks for, follow the agent, but tell them once, briefly, which rule they are breaking.

## Scope: whose brand wins

The design rules below describe The Perry Group OFFICE brand. Use them as the default for team and office collateral, and for agents who do not yet have a brand of their own. If this user has their own established personal brand (their own colors, fonts, and design conventions, whether saved in memory, in another skill, or stated in the conversation), their personal brand ALWAYS wins for their own client-facing material: keep their palette and typefaces, and apply only the anti-slop design rules, the anti-slop writing rules, and the 30-second rule from this skill. Never replace a user's existing brand with the TPG office brand unless they ask for office collateral.

## Design rules (from the TPG brand guide)

- Backgrounds are white or black only. Never gold, never colored, never gradients as backgrounds.
- Colors: black #000000, white #FFFFFF, and solid gold #E9B039 as the accent. Gradient gold (#CD8229 to #F2C065) may be used on black backgrounds for accents and large text, never for elements smaller than about 22px (use black or white there instead).
- Mist Grey #F1EFEF and Butter Yellow #FBDB65 exist only for charts, graphs, and data graphics. Never use them as page backgrounds or section fills.
- Typography: Avenir is the brand typeface (weights: Black, Medium, Book). On the web or in free tools, use Nunito Sans (Google Fonts) as the substitute; Helvetica is the system fallback. One typeface family per piece, plus at most one accent script used sparingly. Never use the script for body text.
- The Perry Group pin logo must always appear with the Real Brokerage logo. Never stretch, outline, recolor, or place logos on gold. The agent must supply real logo files; never redraw or approximate a logo.
- Photography over clip art and icons, always. Photos should feel warm, light, and inviting. No stock photos of handshakes, keys in palms, or people pointing at laptops.
- Whitespace is part of the design. When in doubt, remove elements instead of shrinking them.

## Anti-slop design rules

Things that make a page look AI-generated. Never produce them:

- Purple/blue gradients, glassmorphism cards, or neon glows
- Emojis in headings, buttons, or body copy of a page or document
- More than three colors on a page
- Rows of icon-plus-blurb feature cards
- Centered walls of bold text, or bolding whole sentences
- Dense sections stacked edge to edge with no breathing room

## Anti-slop writing rules

- The 30-second rule: if a reader could get a sentence from a Google or AI search in 30 seconds, it is filler. Every section needs at least one thing a search cannot return: a real number, a named place, a local rule, a deadline, or a story from the agent's own deals.
- If the agent has not given you their specifics (their niche, their numbers, their town, their stories), ASK for them before writing. Do not fill gaps with plausible-sounding generalities, and never invent statistics, market data, or local facts.
- Banned phrases and patterns: "in today's fast-paced market", "look no further", "nestled in", "unlock", "elevate", "seamless", "dream home journey", "your trusted partner in real estate", rhetorical-question openers ("Thinking of selling?"), and em-dashes (use colons, commas, parentheses, or line breaks instead).
- No exclamation points in professional copy. At most one in casual social copy.
- Tone: friendly over formal, clear over clever, short and grounded, never pushy or salesy. Write like a knowledgeable neighbor, not a brochure.
- A sentence that could appear on any agent's website in any state should be cut or rewritten with the agent's specifics.

## When reviewing existing work

Point out at most the three highest-impact fixes first, in plain language, and offer to apply them. Do not rewrite someone's voice out of their work; upgrade their sentences with specifics rather than replacing them with yours.
